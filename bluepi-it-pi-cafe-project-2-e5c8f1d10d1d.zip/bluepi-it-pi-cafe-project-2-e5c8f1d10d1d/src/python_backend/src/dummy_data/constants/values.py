CATEGORIES = [
    {'category_id': 1, 'name': 'Beverages'},
    {'category_id': 2, 'name': 'Breakfast'},
    {'category_id': 3, 'name': 'Lunch'},
    {'category_id': 4, 'name': 'Dinner'},
    {'category_id': 5, 'name': 'Desserts'},
]

FOOD_ITEMS = [
    "Cappuccino", "Latte", "Espresso", "Hot Chocolate", "Iced Tea", "Lemonade",
    "Croissant", "Bagel", "Muffin", "Pancakes", "Waffles", "French Toast",
    "Salad", "Sandwich", "Burger", "Pizza", "Pasta", "Steak",
    "Chicken Parmesan", "Grilled Salmon", "Beef Stew", "Vegetable Curry",
    "Tiramisu", "Cheesecake", "Apple Pie", "Brownies", "Cookies", "Ice Cream",
    "Sushi", "Dumplings", "Tacos", "Burrito", "Falafel", "Hummus",
    "Pad Thai", "Ramen", "Spring Rolls", "Chow Mein", "Kebab", "Gyoza",
    "Biryani", "Curry", "Dosa", "Idli", "Pav Bhaji", "Samosa", "Chaat"
]


WEIGHTS = [5, 5, 50, 70, 50]
