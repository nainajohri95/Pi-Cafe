import os

AWS_ACCESS_KEY_ID = os.environ.get('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY')
BUCKET_NAME = os.environ.get('BUCKET_NAME')
HISTORICAL_DATA_PATH = "Pi_Cafe_raw_data/historical"
MASTER_DATA_PATH = "Pi_Cafe_raw_data/master"
