import sys

print(sys.path)