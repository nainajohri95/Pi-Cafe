package com.picafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PiCafeProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(PiCafeProject2Application.class, args);
	}

}
