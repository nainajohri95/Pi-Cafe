import FoodImage from './foodImage.svg';
import MainLogo from "./mainLogo.svg"
import NavbarLogo from "./navbarLogo.png"


export {FoodImage, MainLogo, NavbarLogo}