import React from "react";
import { AppComponent } from "./Component/Global/AppComponent";



const App = () => {
 
  return (
   <>
   <AppComponent/></>
  );
};

export default App;
