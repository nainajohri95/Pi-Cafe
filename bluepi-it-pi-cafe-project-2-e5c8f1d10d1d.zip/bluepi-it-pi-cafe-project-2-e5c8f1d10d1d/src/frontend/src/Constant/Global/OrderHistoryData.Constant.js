// Sample order history data
export const OrderHistoryData = [
  {
    id: 1,
    custId: "PCP102",
    time: "2:00",
    price: 1500,
  },
  {
    id: 2,
    custId: "PCP103",
    time: "3:00",
    price: 1600,
  },
  {
    id: 3,
    custId: "PCP104",
    time: "4:00",
    price: 1700,
  },
  {
    id: 4,
    custId: "PCP105",
    time: "5:00",
    price: 1800,
  },
  {
    id: 5,
    custId: "PCP106",
    time: "6:00",
    price: 1900,
  },
  {
    id: 6,
    custId: "PCP107",
    time: "7:00",
    price: 2000,
  },
];
