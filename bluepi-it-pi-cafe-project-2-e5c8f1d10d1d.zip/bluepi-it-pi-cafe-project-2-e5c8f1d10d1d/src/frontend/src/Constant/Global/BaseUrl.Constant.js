export const baseUrl = "http://ec2-3-111-171-221.ap-south-1.compute.amazonaws.com:8080";


