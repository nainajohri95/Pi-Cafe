export const customModalStyle = {
    content: {
      width: "700px", // Set the width of the modal
      height: "360px", // Set the height of the modal
      margin: "auto", // Center the modal horizontally
      display: "flex",
      flexDirection: "column",
    },
  };