export const AdminOptions = [
  { title: "Single Order", url: "/" },
  { title: "Order History", url: "/order-history" },
  { title: "Employee Management", url: "/employee-management" },
];

export const EmployeeOptions = [
  { title: "Single Order", url: "/" },
  { title: "Order History", url: "/order-history" },
];
