export const EmployeeData = [
    {empId: "EMP1", name: "John Doe", role: "Employee", salary: 80000},
    {empId: "EMP2", name: "Jane Smith", role: "Employee", salary: 95000},
    {empId: "EMP3", name: "Mike Johnson", role: "Employee", salary: 70000},
    {empId: "EMP4", name: "Emily Davis", role: "Employee", salary: 75000},
    {empId: "EMP5", name: "Robert Brown", role: "Employee", salary: 85000},
    {empId: "EMP6", name: "Linda White", role: "Employee", salary: 92000},
    {empId: "EMP7", name: "James Wilson", role: "Employee", salary: 68000},
    {empId: "EMP8", name: "Sarah Martinez", role: "Employee", salary: 72000},
    {empId: "EMP9", name: "Michael Clark", role: "Employee", salary: 81000},
    {empId: "EMP10", name: "Laura Lewis", role: "Employee", salary: 78000},
    {empId: "EMP11", name: "David Hall", role: "Employee", salary: 74000},
    {empId: "EMP12", name: "Jennifer Young", role: "Employee", salary: 89000},
   
]
