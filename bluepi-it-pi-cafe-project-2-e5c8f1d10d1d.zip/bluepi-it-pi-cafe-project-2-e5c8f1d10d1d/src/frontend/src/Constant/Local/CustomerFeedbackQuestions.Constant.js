export const CustomerFeedbackQuestions = [
  
  {question: "How satisfied were you with your overall experience at our cafe?", type: "foodrating", index: 0},
  {question: "How would you rate the hygiene and quality of the food you ordered?", type: "customerexprating", index: 1},
  {question: "How would you rate the ambiance of our cafe?", type: "ambiancerating", index: 2},
];
